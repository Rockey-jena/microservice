package com.serviceRepository;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRepositoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRepositoryApplication.class, args);
	}

}
